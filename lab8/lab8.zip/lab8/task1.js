const raceResults = ([first, second, third, ...rest]) => ({first, second, third, rest})
raceResults(['Tom', 'Margaret', 'Allison', 'David', 'Pierre'])


