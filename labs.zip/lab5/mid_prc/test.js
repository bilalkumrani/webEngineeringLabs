let a = '1';
function ok ()
{
    console.log(a);
}
console.log(ok());


