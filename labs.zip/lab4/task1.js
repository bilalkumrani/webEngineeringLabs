let val = 12; //integer
let val1 = 12.5; //float
let val2 = "Hello World"; //string
let val3 = true; //boolean
let val4 = new Date(); //date
let val5;   // undefined
let val6 = [1,2,3,4,5]; // array of integers
let val7 = ['hi','hello','how are you']; // array of strings
let val8 = [true,5,"hello",undefined,Date]; // array of Mixed elements
let obj = {
    id : "1",
    name : "bilal"
};



