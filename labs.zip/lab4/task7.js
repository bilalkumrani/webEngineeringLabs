
let txt = "Bilal";
let split = txt.split("");
let rev = split.reverse();
let ok = rev.join('');
console.log(ok);