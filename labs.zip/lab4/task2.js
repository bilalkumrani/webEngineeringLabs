console.log(Number("122a")); // it the whole string if it finds any non digit it will return NaN else it will convert it into integer


console.log(parseInt("122a")); //it will check from start and convert them into inger untill it finds non digit value

console.log(parseFloat("122.3a")); // it will work like parseInt it will check from starting of string